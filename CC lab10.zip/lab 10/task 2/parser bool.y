%{
#include <stdio.h>

int yylex();
int yyerror(char *s);
%}

%union {
    int ival;
}

%token <ival> BOOL
%token AND OR NOT
%type <ival> expr

%left OR
%left AND
%right NOT

%%

input:
      /* empty */
    | input line
    ;

line:
      '\n'
    | expr '\n'   { printf("= %s\n", $1 ? "true" : "false"); }
    ;

expr:
      BOOL                { $$ = $1; }
    | '(' expr ')'        { $$ = $2; }
    | expr AND expr       { $$ = $1 && $3; }
    | expr OR expr        { $$ = $1 || $3; }
    | NOT expr            { $$ = !$2; }
    ;

%%

int main() {
    yyparse();
    return 0;
}

int yyerror(char *s) {
    fprintf(stderr, "Error: %s\n", s);
    return 0;
}
